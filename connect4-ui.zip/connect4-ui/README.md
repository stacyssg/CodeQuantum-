# Connect 4 — Beginner-Friendly Hackathon Build

A simple Connect 4 web app built with plain HTML, CSS, and JavaScript.

## Files

- `index.html` — page structure
- `styles.css` — styling and responsive layout
- `script.js` — game logic and UI state
- `assets/wallpaper.png` — branded artwork used on the home screen and result screen

## Features

- 2-player mode
- basic computer opponent mode
- restart round
- reset scores
- home screen using your AI wallpaper
- win/draw modal
- keyboard support with keys `1` to `7`
- responsive layout for desktop and mobile

## How to Run

### Option 1: VS Code Live Server
1. Open the folder in your Codespace.
2. Install the **Live Server** extension if needed.
3. Right-click `index.html`.
4. Click **Open with Live Server**.

### Option 2: Python local server
From the project folder, run:

```bash
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## Team Notes

If your team already has a bigger app:
- move these files into a `frontend/` or `public/` folder
- keep the `assets/` folder path the same, or update image paths in `index.html` and `styles.css`

## Easy Custom Edits

### Change the title text
Edit in `index.html`:
- `Connect 4`
- `An App of Utopian Discovery`

### Change colors
Edit CSS variables at the top of `styles.css`.

### Make it only 2-player
In `index.html`, remove the **Play vs Computer** button.
In `script.js`, remove the CPU button event and CPU logic if your team wants a smaller demo.
